<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package news_themes
 */

?>

	<footer id="colophon" class="site-footer">
		<div class="site-footer-info">
			<div class="site-footer-branding">
				<?php the_custom_logo(); ?>
			</div><!-- .site-branding -->
			<div class="site-footer-copyright">
				<?php
				/* translators: %s: CMS name, i.e. WordPress. */
				printf( esc_html__( '@2020 %s %s', 'news_themes' ), 'Nationwide News Pty Limited', 'All rights reserved.' );
				?>
			</div>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
