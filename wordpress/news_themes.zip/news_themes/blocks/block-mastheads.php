<div class="mastheads-block clearfix">
  <div class="mastheads-container">
    <?php
      /*
      // http://www.hexsoftstudio.com/demo/request-quote/
      // http://www.hexsoftstudio.com/demo/wp-content/themes/news_themes/json/mastheads.json
      $url = block_field( 'logo-urls' );
      $resp = wp_remote_get( trailingslashit( $url ) );
      var_dump( $resp );
      // Error: A valid URL was not provided
      */

      $url = get_template_directory_uri() . '/json/mastheads.json';
      $response = wp_remote_get( $url );
      if( is_wp_error( $response ) ) {
         $error_message = $response->get_error_message();
         echo "Something went wrong: $error_message";
      } else {
        // print_r( $response[body] );
        // Retrieve the data
        $data = json_decode( $response[body] );
        $masheadTop = array_slice($data, 0, 4);
        $masheadBottom = array_slice($data, 4);
    ?>
    <div class="mastheads-logos-top">
      <?php foreach ( $masheadTop as $masthead) {
        $imageurl = get_template_directory_uri() . '/assets/' . $masthead->image ;
      ?>
        <div class="mastheads-image">
          <img src="<?php echo( $imageurl ) ?>" />
        </div>
      <?php };?>
    </div>
    <div class="mastheads-separator"></div>
    <div class="mastheads-logos-bottom">
      <?php foreach ( $masheadBottom as $masthead) {
        $imageurl = get_template_directory_uri() . '/assets/' . $masthead->image ;
      ?>
        <div class="mastheads-image">
          <img src="<?php echo( $imageurl ) ?>" />
        </div>
      <?php };?>
    </div>
    <?php
      };
    ?>
  </div>
</div>
