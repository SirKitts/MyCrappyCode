<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package news_themes
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'news_themes' ); ?></a>

	<header id="masthead" class="site-header">
		<div style="clear: both;">
			<div class="site-branding-left">CORPORATE NEWS SUBSCRIPTION</div>
			<div class="site-branding-right site-branding">
				<img src="<?php echo(get_template_directory_uri() . '/assets/TheAustralinColored.png') ?>"
					height="35"
					width="200"
					alt="The Australian">
			</div><!-- .site-branding -->
		</div>

		<?php if ( get_header_image() ) : ?>
			<div id="site-header" class="site-header">
					<img src="<?php header_image(); ?>"
						width="100%"
						height="<?php echo absint( get_custom_header()->height ); ?>"
						alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">

					<div class="site-header-description">
						<?php
						$news_themes_description = get_bloginfo( 'description', 'display' );
						if ( $news_themes_description || is_customize_preview() ) :
							?>
							<div class="site-description">
								<?php echo $news_themes_description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							</div>
						<?php endif; ?>
						<button class="button-request-quote">
							Request A Quote
						</button>
					</div>
			</div>
		<?php endif; ?>
	</header><!-- #masthead -->
